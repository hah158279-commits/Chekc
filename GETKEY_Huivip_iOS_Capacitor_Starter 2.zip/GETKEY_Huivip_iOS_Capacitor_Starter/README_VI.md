# GETKEY · 후이vip👑 — iOS Capacitor starter

Đây là **bộ source khởi tạo app iOS**, chưa phải file IPA đã ký/cài được. Muốn tạo app cài riêng trên iPhone cần máy Mac có Xcode và quy trình ký ứng dụng Apple.

## App hiện tại
- Tên: GETKEY 후이vip
- Bundle ID: `com.huivip.getkey`
- Màu chủ đạo: neon xanh lá/xanh cyan, nền tối
- Màn mở đầu local có nút mở bảng quản trị.
- Sau khi mở, app dùng bảng quản trị đang host tại Render: `https://getkey-huivip.onrender.com/getkey/`.

## Cần biết trước
Bản starter này là vỏ Capacitor kết nối bảng quản trị online, nên **cần Internet và máy chủ Render hoạt động**. Đây chưa phải app offline hoặc bản native viết lại hoàn toàn. Nếu muốn phân phối công khai qua App Store, Apple có thể yêu cầu app có giá trị native rõ ràng hơn một web wrapper; cần kiểm tra guideline hiện hành trước khi gửi duyệt.

## Tạo project trên Mac
Cài Node.js LTS và Xcode trước. Mở Terminal trong thư mục đã giải nén rồi chạy:

```bash
npm install
npx cap add ios
npx cap sync ios
npx cap open ios
```

Trong Xcode:
1. Chọn target `App` → `Signing & Capabilities`.
2. Chọn Team của Apple Developer account.
3. Đổi Bundle Identifier nếu bị trùng.
4. Chọn iPhone đang kết nối hoặc thiết bị test, bấm Run.
5. Để cài lên iPhone khác hoặc phát hành, cần signing/provisioning đúng cách; không thể tạo IPA ký hợp lệ chỉ từ iPhone/Safari.

## Lưu ý bảo mật quan trọng
- Đổi `ADMIN_PASSWORD` và `SESSION_SECRET` trong Render Environment trước khi dùng thật. Không dùng mật khẩu mẫu.
- Mật khẩu admin phải được kiểm tra ở server; không nhúng mật khẩu vào ứng dụng.
- Render Free có thể ngủ khi không dùng; lần mở đầu có thể chậm.
- Đã có API key/session prototype; trước khi bán thật cần kiểm thử bảo mật, rate limit đăng nhập và backup dữ liệu.
- Nếu trang Render chưa mở được trên Safari, app cũng chưa thể mở bảng quản trị. Hãy xác nhận URL hoạt động trước khi build.
