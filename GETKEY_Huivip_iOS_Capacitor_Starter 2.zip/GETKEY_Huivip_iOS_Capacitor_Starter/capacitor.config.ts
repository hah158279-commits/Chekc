import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.huivip.getkey',
  appName: 'GETKEY 후이vip',
  webDir: 'www',
  server: {
    // Online admin console; the hosted Render service must be live.
    url: 'https://getkey-huivip.onrender.com/getkey/',
    cleartext: false,
    allowNavigation: ['getkey-huivip.onrender.com']
  },
  ios: {
    contentInset: 'automatic',
    preferredContentMode: 'mobile'
  }
};
export default config;
