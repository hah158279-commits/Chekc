// ==UserScript==
// @name         후이 - Auto Message Ultimate (Pro Pink Edition)
// @namespace    http://tampermonkey.net/
// @version      4.0
// @description  Giao diện hồng kính mờ chuyên nghiệp, mang bản quyền 후이, hoa rơi lấp lánh, chọn MP3, đếm tin nhắn.
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    if (document.getElementById('auto-msg-panel')) return;

    // 1. Tạo Canvas cho hiệu ứng hoa rơi toàn màn hình (Tông hồng lấp lánh)
    const canvas = document.createElement('canvas');
    canvas.id = 'am-canvas';
    canvas.style.cssText = 'position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:999998; pointer-events:none;';
    document.body.appendChild(canvas);
    const ctx = canvas.getContext('2d');

    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    const petals = [];
    const numPetals = 40;
    const colors = ['#ffb7c5', '#ffc0cb', '#ff9ebb', '#e6a8d7', '#ffffff', '#ffd1dc'];
    for (let i = 0; i < numPetals; i++) {
        petals.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height - canvas.height,
            r: Math.random() * 4.5 + 2,
            d: Math.random() * numPetals,
            color: colors[Math.floor(Math.random() * colors.length)],
            speed: Math.random() * 1.6 + 0.5
        });
    }

    function animatePetals() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        for (let i = 0; i < numPetals; i++) {
            let p = petals[i];
            ctx.fillStyle = p.color;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2, true);
            ctx.fill();

            p.y += p.speed;
            p.x += Math.sin(p.d) * 0.6;
            if (p.y > canvas.height) {
                p.y = -15;
                p.x = Math.random() * canvas.width;
            }
        }
        requestAnimationFrame(animatePetals);
    }
    animatePetals();

    // Inject CSS Animation hiệu ứng viền lấp lánh chuyên nghiệp
    const styleSheet = document.createElement("style");
    styleSheet.type = "text/css";
    styleSheet.innerHTML = `
        @keyframes pinkGlow {
            0% { box-shadow: 0 10px 30px rgba(0,0,0,0.5), 0 0 15px rgba(255, 183, 197, 0.4); border-color: rgba(255, 183, 197, 0.6); }
            50% { box-shadow: 0 15px 40px rgba(0,0,0,0.6), 0 0 30px rgba(255, 192, 203, 0.9); border-color: rgba(255, 192, 203, 1); }
            100% { box-shadow: 0 10px 30px rgba(0,0,0,0.5), 0 0 15px rgba(255, 183, 197, 0.4); border-color: rgba(255, 183, 197, 0.6); }
        }
        .pink-elite-panel {
            animation: pinkGlow 4s infinite ease-in-out;
        }
    `;
    document.head.appendChild(styleSheet);

    // 2. Tạo bảng điều khiển giao diện nổi (Pro Pink Glassmorphism)
    const container = document.createElement('div');
    container.className = "pink-elite-panel";
    container.innerHTML = `
        <div id="auto-msg-panel" style="
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 999999;
            background: linear-gradient(145deg, rgba(30, 20, 35, 0.92), rgba(20, 15, 25, 0.96));
            backdrop-filter: blur(18px);
            -webkit-backdrop-filter: blur(18px);
            color: #ffd1dc;
            padding: 16px;
            border-radius: 16px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            width: 290px;
            font-size: 12px;
            border: 2px solid #ffb7c5;
        ">
            <div style="font-weight: 800; margin-bottom: 10px; color: #fff; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255,183,197,0.3); padding-bottom: 8px;">
                <div style="display: flex; align-items: center; gap: 6px;">
                    <span style="font-size: 16px; filter: drop-shadow(0 0 6px #ffb7c5);">🌸</span>
                    <div>
                        <span style="color: #ffb7c5; font-size: 13px; letter-spacing: 0.5px;">후이 - ULTIMATE</span>
                        <div style="font-size: 8px; color: #e6a8d7; font-weight: 600;">[EXCLUSIVE PRO EDITION]</div>
                    </div>
                </div>
                <button id="am-toggle-minimize" style="background:rgba(255,183,197,0.2); border:1px solid #ffb7c5; color:#fff; font-size:14px; cursor:pointer; padding: 2px 8px; border-radius:6px; font-weight:bold;">−</button>
            </div>
            <div id="am-content">
                <div style="margin-bottom: 4px; font-size: 10px; color: #e6a8d7; font-weight: 700;">NỘI DUNG TIN NHẮN:</div>
                <textarea id="am-text" style="width: 100%; height: 50px; background: rgba(15, 10, 20, 0.8); color: #fff; border: 1px solid rgba(255,183,197,0.4); border-radius: 8px; padding: 8px; resize: none; box-sizing: border-box; font-size: 12px; outline: none;">Hello! 🌸</textarea>
                
                <div style="margin: 8px 0 3px 0; font-size: 10px; color: #e6a8d7; font-weight: 700;">DELAY: <span id="am-delay-val" style="color: #ff9ebb; font-weight: bold;">1.0</span> GIÂY</div>
                <input type="range" id="am-delay" min="0.5" max="5" step="0.5" value="1.0" style="width: 100%; accent-color: #ffb7c5; cursor: pointer;">

                <div style="margin: 8px 0 3px 0; font-size: 10px; color: #e6a8d7; font-weight: 700;">CHỌN FILE NHẠC MP3:</div>
                <input type="file" id="am-audio-file" accept="audio/mp3, audio/*" style="font-size: 10px; color: #ffd1dc; width: 100%; margin-bottom: 6px; background: rgba(15,10,20,0.6); padding: 4px; border-radius: 6px; border: 1px dashed rgba(255,183,197,0.4);">
                <audio id="am-audio" loop style="display:none;"></audio>

                <div id="am-status" style="margin: 6px 0; font-style: italic; color: #e6a8d7; font-size: 11px; background: rgba(255,183,197,0.1); padding: 5px 8px; border-radius: 6px; border-left: 3px solid #ffb7c5;">Trạng thái: Sẵn sàng (Đã gửi: 0)</div>
                
                <div style="display: flex; gap: 6px; margin-top: 8px;">
                    <button id="am-start" style="flex:1; background: linear-gradient(135deg, #ff9ebb, #ffb7c5); color: #1a0f1a; border: none; padding: 8px; border-radius: 8px; font-weight: bold; cursor: pointer; font-size: 12px; box-shadow: 0 4px 12px rgba(255,183,197,0.4);">BẮT ĐẦU</button>
                    <button id="am-end" style="flex:1; background: linear-gradient(135deg, #f38ba8, #e06c75); color: #fff; border: none; padding: 8px; border-radius: 8px; font-weight: bold; cursor: pointer; font-size: 12px; display: none; box-shadow: 0 4px 12px rgba(243,139,168,0.4);">DỪNG</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(container);

    const textInput = document.getElementById('am-text');
    const delayRange = document.getElementById('am-delay');
    const delayVal = document.getElementById('am-delay-val');
    const audioFile = document.getElementById('am-audio-file');
    const audioElement = document.getElementById('am-audio');
    const statusText = document.getElementById('am-status');
    const startBtn = document.getElementById('am-start');
    const endBtn = document.getElementById('am-end');
    const minimizeBtn = document.getElementById('am-toggle-minimize');
    const amContent = document.getElementById('am-content');

    delayRange.addEventListener('input', () => {
        delayVal.innerText = delayRange.value;
    });

    let minimized = false;
    minimizeBtn.addEventListener('click', () => {
        minimized = !minimized;
        amContent.style.display = minimized ? 'none' : 'block';
        minimizeBtn.innerText = minimized ? '+' : '−';
    });

    // Xử lý chọn file nhạc MP3 trực tiếp từ iPhone
    audioFile.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const fileURL = URL.createObjectURL(file);
            audioElement.src = fileURL;
            audioElement.play().catch(err => console.log('Không tự phát được nhạc:', err));
        }
    });

    let isRunning = false;
    let timer = null;
    let sentCount = 0;

    function simulateSend(message) {
        let activeEl = document.activeElement;
        if (!activeEl || (activeEl.tagName !== 'TEXTAREA' && activeEl.tagName !== 'INPUT' && !activeEl.isContentEditable)) {
            activeEl = document.querySelector('div[contenteditable="true"], textarea, input[type="text"]');
        }

        if (activeEl) {
            activeEl.focus();
            if (activeEl.isContentEditable) {
                document.execCommand('insertText', false, message);
            } else {
                let start = activeEl.selectionStart || 0;
                let end = activeEl.selectionEnd || 0;
                let val = activeEl.value || '';
                activeEl.value = val.substring(0, start) + message + val.substring(end);
                activeEl.selectionStart = activeEl.selectionEnd = start + message.length;
                activeEl.dispatchEvent(new Event('input', { bubbles: true }));
            }

            setTimeout(() => {
                const enterEvent = new KeyboardEvent('keydown', {
                    key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true
                });
                activeEl.dispatchEvent(enterEvent);

                const sendBtn = document.querySelector('button[aria-label*="Send"], button[aria-label*="Gửi"], button[type="submit"], div[aria-label*="Send"]');
                if (sendBtn) {
                    sendBtn.click();
                }
            }, 50);
        }
    }

    startBtn.addEventListener('click', () => {
        const msg = textInput.value.trim();
        if (!msg) {
            alert('Vui lòng nhập nội dung tin nhắn!');
            return;
        }

        if (audioElement.src && audioElement.paused) {
            audioElement.play().catch(e => console.log(e));
        }

        isRunning = true;
        sentCount = 0;
        startBtn.style.display = 'none';
        endBtn.style.display = 'block';

        function loop() {
            if (!isRunning) return;

            simulateSend(msg);
            sentCount++;
            statusText.innerText = `Trạng thái: Đang chạy... (Đã gửi: ${sentCount})`;

            const delaySec = parseFloat(delayRange.value) * 1000;
            timer = setTimeout(loop, delaySec);
        }

        statusText.style.color = "#ff9ebb";
        loop();
    });

    endBtn.addEventListener('click', () => {
        isRunning = false;
        clearTimeout(timer);
        startBtn.style.display = 'block';
        endBtn.style.display = 'none';
        statusText.innerText = `Trạng thái: Đã dừng! (Đã gửi: ${sentCount})`;
        statusText.style.color = "#f38ba8";
    });
})();