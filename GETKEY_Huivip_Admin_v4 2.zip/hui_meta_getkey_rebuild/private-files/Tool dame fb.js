// ==UserScript==
// @name         후이 - FB Auto Report (Pro Elite Edition)
// @namespace    http://tampermonkey.net/
// @version      14.0
// @description  Bản chuyên nghiệp tối ưu chống lỗi, giao diện Cyberpunk kính mờ phát sáng lấp lánh, hoa rơi mượt mà.
// @author       후이 & Elite Developer
// @match        https://*.facebook.com/*
// @run-at       document-end
// @grant        none
// ==/UserScript==

(async () => {
    'use strict';

    // ==========================================
    // 1. HIỆU ỨNG HOA RƠI MÀU TÍM LẤP LÁNH
    // ==========================================
    const canvas = document.createElement('canvas');
    canvas.style.cssText = 'position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483646; pointer-events:none;';
    document.body.appendChild(canvas);
    const ctx = canvas.getContext('2d');

    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    const petals = [];
    const numPetals = 45;
    const colors = ['#f3e8ff', '#e9d5ff', '#d8b4fe', '#c084fc', '#a855f7', '#9333ea', '#ff79c6'];
    for (let i = 0; i < numPetals; i++) {
        petals.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height - canvas.height,
            r: Math.random() * 4.5 + 2,
            d: Math.random() * numPetals,
            color: colors[Math.floor(Math.random() * colors.length)],
            speed: Math.random() * 1.8 + 0.5
        });
    }

    function animatePetals() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        for (let i = 0; i < numPetals; i++) {
            let p = petals[i];
            ctx.fillStyle = p.color;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2, true);
            ctx.fill();

            p.y += p.speed;
            p.x += Math.sin(p.d) * 0.7;
            if (p.y > canvas.height) {
                p.y = -15;
                p.x = Math.random() * canvas.width;
            }
        }
        requestAnimationFrame(animatePetals);
    }
    animatePetals();

    // ==========================================
    // CẤU HÌNH BƯỚC & XPATH THÔNG MINH
    // ==========================================
    const INPUT_XPATH = "//*[@aria-label=\"Facebook Page name or URL\" or contains(@aria-label, \"name\") or contains(@aria-label, \"URL\")]";
    const XP_SUBMIT = "//span[contains(text(), 'Submit') or contains(text(), 'Gửi') or contains(text(), '送信')]";
    const XP_DONE   = "//span[contains(text(), 'Done') or contains(text(), 'Xong') or contains(text(), 'Hoàn tất') or contains(text(), '完了')]";
    const XP_NEXT   = "//span[contains(text(), 'Next') or contains(text(), 'Tiếp') or contains(text(), '次へ')]";

    const steps = [
        { "step": 1, "name": "Menu (3 chấm)", "xpath": "//*[@aria-label=\"Profile settings see more options\" or contains(@aria-label, \"options\")]" },
        { "step": 2, "name": "Report profile", "xpath": "//SPAN[contains(text(), \"Report profile\") or contains(text(), \"Report\")]" },
        { "step": 3, "name": "Something about this profile", "xpath": "//SPAN[contains(text(), \"Something about this profile\")]" },
        { "step": 4, "name": "Fake profile", "xpath": "//SPAN[contains(text(), \"Fake profile\")]" },
        { "step": 5, "name": "They’re not a real person", "xpath": "//SPAN[contains(text(), \"They’re not a real person\")]" },
        { "step": 6, "name": "Submit", "xpath": XP_SUBMIT },
        { "step": 7, "name": "Next", "xpath": XP_NEXT },
        { "step": 8, "name": "Done", "xpath": XP_DONE },

        { "step": 9, "name": "Menu (3 chấm)", "xpath": "//*[@aria-label=\"Profile settings see more options\" or contains(@aria-label, \"options\")]" },
        { "step": 10, "name": "Report profile", "xpath": "//SPAN[contains(text(), \"Report profile\")]" },
        { "step": 11, "name": "Something about this profile", "xpath": "//SPAN[contains(text(), \"Something about this profile\")]" },
        { "step": 12, "name": "Fake profile", "xpath": "//SPAN[contains(text(), \"Fake profile\")]" },
        { "step": 13, "name": "A celebrity or public figure", "xpath": "//SPAN[contains(text(), \"A celebrity or public figure\")]" },
        { "step": 14, "name": "NHẬP TÊN: Meta", "xpath": INPUT_XPATH, "inputData": "Meta" },
        { "step": 15, "name": "Click Chọn Meta", "specialAction": "CLICK_META_RESULT" },
        { "step": 16, "name": "Next", "xpath": XP_NEXT },
        { "step": 17, "name": "Submit", "xpath": XP_SUBMIT },
        { "step": 18, "name": "Next", "xpath": XP_NEXT },
        { "step": 19, "name": "Done", "xpath": XP_DONE },

        { "step": 20, "name": "Menu (3 chấm)", "xpath": "//*[@aria-label=\"Profile settings see more options\" or contains(@aria-label, \"options\")]" },
        { "step": 21, "name": "Report profile", "xpath": "//SPAN[contains(text(), \"Report profile\")]" },
        { "step": 22, "name": "Something about this profile", "xpath": "//SPAN[contains(text(), \"Something about this profile\")]" },
        { "step": 23, "name": "Problem involving someone under 18", "xpath": "//SPAN[contains(text(), \"Problem involving someone under 18\")]" },
        { "step": 24, "name": "Physical abuse", "xpath": "//SPAN[contains(text(), \"Physical abuse\")]" },
        { "step": 25, "name": "Submit", "xpath": XP_SUBMIT },
        { "step": 26, "name": "Next", "xpath": XP_NEXT },
        { "step": 27, "name": "Done", "xpath": XP_DONE },

        { "step": 28, "name": "Menu (3 chấm)", "xpath": "//*[@aria-label=\"Profile settings see more options\" or contains(@aria-label, \"options\")]" },
        { "step": 29, "name": "Report profile", "xpath": "//SPAN[contains(text(), \"Report profile\")]" },
        { "step": 30, "name": "Something about this profile", "xpath": "//SPAN[contains(text(), \"Something about this profile\")]" },
        { "step": 31, "name": "Violent, hateful content", "xpath": "//SPAN[contains(text(), \"Violent, hateful or disturbing content\")]" },
        { "step": 32, "name": "Credible threat to safety", "xpath": "//SPAN[contains(text(), \"Credible threat to safety\")]" },
        { "step": 33, "name": "Submit", "xpath": XP_SUBMIT },
        { "step": 34, "name": "Next", "xpath": XP_NEXT },
        { "step": 35, "name": "Done", "xpath": XP_DONE },

        { "step": 36, "name": "Menu (3 chấm)", "xpath": "//*[@aria-label=\"Profile settings see more options\" or contains(@aria-label, \"options\")]" },
        { "step": 37, "name": "Report profile", "xpath": "//SPAN[contains(text(), \"Report profile\")]" },
        { "step": 38, "name": "Something about this profile", "xpath": "//SPAN[contains(text(), \"Something about this profile\")]" },
        { "step": 39, "name": "Scam, fraud", "xpath": "//SPAN[contains(text(), \"Scam, fraud or false information\")]" },
        { "step": 40, "name": "Fraud or scam", "xpath": "//SPAN[contains(text(), \"Fraud or scam\")]" },
        { "step": 41, "name": "Submit", "xpath": XP_SUBMIT },
        { "step": 42, "name": "Next", "xpath": XP_NEXT },
        { "step": 43, "name": "Done", "xpath": XP_DONE },

        { "step": 44, "name": "Menu (3 chấm)", "xpath": "//*[@aria-label=\"Profile settings see more options\" or contains(@aria-label, \"options\")]" },
        { "step": 45, "name": "Report profile", "xpath": "//SPAN[contains(text(), \"Report profile\")]" },
        { "step": 46, "name": "Something about this profile", "xpath": "//SPAN[contains(text(), \"Something about this profile\")]" },
        { "step": 47, "name": "Scam, fraud", "xpath": "//SPAN[contains(text(), \"Scam, fraud or false information\")]" },
        { "step": 48, "name": "Spam", "xpath": "//SPAN[contains(text(), \"Spam\")]" },
        { "step": 49, "name": "Done", "xpath": XP_DONE },

        { "step": 50, "name": "Menu (3 chấm)", "xpath": "//*[@aria-label=\"Profile settings see more options\" or contains(@aria-label, \"options\")]" },
        { "step": 51, "name": "Report profile", "xpath": "//SPAN[contains(text(), \"Report profile\")]" },
        { "step": 52, "name": "Something about this profile", "xpath": "//SPAN[contains(text(), \"Something about this profile\")]" },
        { "step": 53, "name": "Something else", "xpath": "//SPAN[contains(text(), \"Something else\")]" },
        { "step": 54, "name": "Done", "xpath": XP_DONE }
    ];

    const sleep = ms => new Promise(r => setTimeout(r, ms));

    function getElementByXpath(path) {
        try {
            if (!path) return null;
            return document.evaluate(path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
        } catch (e) {
            return null;
        }
    }

    function safeClick(element) {
        if (!element) return;
        let blocker = element.closest('[aria-hidden="true"]');
        if (blocker) blocker.removeAttribute('aria-hidden');
        element.scrollIntoView({block: "center", inline: "center"});
        const opts = { bubbles: true, cancelable: true, view: window };
        element.dispatchEvent(new MouseEvent('mousedown', opts));
        element.dispatchEvent(new MouseEvent('mouseup', opts));
        element.dispatchEvent(new MouseEvent('click', opts));
    }

    async function waitForElementToDisappear(element) {
        let maxWait = 40;
        while (maxWait > 0) {
            if (!element || !element.isConnected || element.offsetParent === null) return true;
            await sleep(100);
            maxWait--;
        }
        return false;
    }

    async function waitForGlobalLoading(statusCallback) {
        let maxWait = 80;
        let isWaiting = false;
        while (maxWait > 0) {
            let loadingIcon = document.querySelector('[role="progressbar"], img[src*="loading"], i[class*="loading"]');
            if (loadingIcon && loadingIcon.offsetParent !== null) {
                isWaiting = true;
                if(statusCallback) statusCallback("⏳ Đang đồng bộ...", "#e9d5ff");
                await sleep(100);
                maxWait--;
            } else {
                if(isWaiting) await sleep(400); 
                return;
            }
        }
    }

    function findButtonSmart(keywords) {
        let all = [...document.querySelectorAll('div[role="menuitem"], div[role="button"], button, span, div[role="dialog"] span, div[aria-label], div[tabindex="0"]')];
        all = all.filter(el => el && el.offsetParent !== null && el.offsetWidth > 0);
        for (let el of all) {
            let txt = (el.innerText || "").trim();
            let label = (el.getAttribute("aria-label") || "").trim();
            for (let k of keywords) {
                if (txt === k || label === k || txt.toLowerCase().includes(k.toLowerCase()) || label.toLowerCase().includes(k.toLowerCase())) {
                    let parentBtn = el.closest('div[role="button"], button, div[role="menuitem"], div[tabindex="0"]');
                    return parentBtn ? parentBtn : el;
                }
            }
        }
        return null;
    }

    function simulateInput(element, text) {
        element.focus();
        let lastValue = element.value || "";
        element.value = text;
        let event = new Event('input', { bubbles: true });
        let tracker = element._valueTracker;
        if (tracker) { tracker.setValue(lastValue); }
        element.dispatchEvent(event);
        element.dispatchEvent(new Event('change', { bubbles: true }));
    }

    async function clickMetaResult(statusEl) {
        let retry = 12;
        while (retry > 0) {
            let options = document.querySelectorAll('div[role="listbox"] span, ul[role="listbox"] span, div[role="presentation"] span, div[role="option"]');
            for (let span of options) {
                if (span.innerText && span.innerText.trim().toLowerCase().includes("meta")) {
                    statusEl.innerText = "Đã chọn 'Meta'...";
                    safeClick(span);
                    return true;
                }
            }
            let imgs = document.querySelectorAll('div[role="listbox"] img');
            if (imgs.length > 0) {
                 safeClick(imgs[0]);
                 return true;
            }
            statusEl.innerText = `Tìm Meta... (${retry})`;
            await sleep(500);
            retry--;
        }
        return false;
    }

    let audioLoop = null;
    let titleInterval = null;
    const SILENT_AUDIO = 'data:audio/mp3;base64,SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU4LjIwLjEwMAAAAAAAAAAAAAAA//OEAAAAAAAAAAAAAAAAAAAAAAAASW5mbwAAAA8AAAAEAAABIADAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMD//////////////////////////////////////////////////////////////////wAAADFMYXZjNTguMzUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAIAAAAASAA8AxAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//OEAAAAAAAAAAAAAAAAAAAAAAAATGF2YzU4LjM1LjEwMAAAAAAAAAAAAAAA//OEAAAAAAAAAAAAAAAAAAAAAAAATGF2YzU4LjM1LjEwMAAAAAAAAAAAAAAA//OEAAAAAAAAAAAAAAAAAAAAAAAATGF2YzU4LjM1LjEwMAAAAAAAAAAAAAAA//OEAAAAAAAAAAAAAAAAAAAAAAAATGF2YzU4LjM1LjEwMAAAAAAAAAAAAAAA//OEAAAAAAAAAAAAAAAAAAAAAAAATGF2YzU4LjM1LjEwMAAAAAAAAAAAAAAA';

    function toggleAntiSleep(enable) {
        if (enable) {
            if (!audioLoop) {
                audioLoop = new Audio(SILENT_AUDIO);
                audioLoop.loop = true;
                audioLoop.volume = 0.01;
            }
            audioLoop.play().catch(e => console.log("Anti-sleep active"));
            let tick = false;
            if (titleInterval) clearInterval(titleInterval);
            titleInterval = setInterval(() => {
                document.title = tick ? "⚡ [HOẠT ĐỘNG] 후이 ELITE" : "🛡️ [SECURE] 후이 AUTO";
                tick = !tick;
            }, 2000);
        } else {
            if (audioLoop) audioLoop.pause();
            if (titleInterval) {
                clearInterval(titleInterval);
                document.title = "Facebook";
            }
        }
    }

    // ==========================================
    // UI ELITE CYBERPUNK PANEL (LẤP LÁNH & ĐỈNH CAO)
    // ==========================================
    let isPaused = false;
    let shouldStop = false;
    let isMini = false; 
    let successCount = 0;

    // Inject CSS Animation cho hiệu ứng viền lấp lánh chuyên nghiệp
    const styleSheet = document.createElement("style");
    styleSheet.type = "text/css";
    styleSheet.innerHTML = `
        @keyframes eliteGlow {
            0% { box-shadow: 0 0 15px rgba(168, 85, 247, 0.4), inset 0 0 15px rgba(168, 85, 247, 0.2); border-color: #a855f7; }
            50% { box-shadow: 0 0 35px rgba(232, 121, 249, 0.8), inset 0 0 25px rgba(232, 121, 249, 0.4); border-color: #e879f9; }
            100% { box-shadow: 0 0 15px rgba(168, 85, 247, 0.4), inset 0 0 15px rgba(168, 85, 247, 0.2); border-color: #a855f7; }
        }
        .elite-panel {
            animation: eliteGlow 4s infinite ease-in-out;
        }
    `;
    document.head.appendChild(styleSheet);

    const panel = document.createElement("div");
    panel.className = "elite-panel";
    const fullStyle = {
        position: "fixed", top: "70px", right: "20px", width: "290px",
        background: "linear-gradient(145deg, rgba(18, 16, 43, 0.92), rgba(10, 10, 25, 0.96))",
        backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)",
        color: "#f3e8ff", padding: "16px", borderRadius: "18px", zIndex: 2147483647,
        border: "2px solid #a855f7",
        fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
        fontSize: "12px", transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
    };
    Object.assign(panel.style, fullStyle);

    const renderPanel = () => {
        if (isMini) {
            panel.innerHTML = `
                <div style="display:flex; align-items:center; gap:8px;">
                     <span style="font-size:16px; filter: drop-shadow(0 0 6px #c084fc);">👑</span>
                     <div style="flex:1; background:rgba(15, 23, 42, 0.9); height:8px; border-radius:4px; overflow:hidden; border:1px solid rgba(168,85,247,0.4);">
                         <div id="miniBar" style="width:0%; height:100%; background:linear-gradient(90deg, #c084fc, #e879f9);"></div>
                     </div>
                     <span id="miniCount" style="font-size:11px; color:#e879f9; font-weight:bold;">[${successCount}]</span>
                     <button id="btnExpand" style="background:rgba(147, 51, 234, 0.4); border:1px solid #c084fc; color:#fff; cursor:pointer; border-radius:4px; padding:2px 7px; font-weight:bold;">+</button>
                </div>
                <div id="miniStt" style="font-size:10px; color:#d8b4fe; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; margin-top:5px;">⚡ 후이 Pro Ready</div>
            `;
            panel.style.width = "195px";
            panel.style.padding = "8px 12px";
            
            const btnExpand = panel.querySelector("#btnExpand");
            btnExpand.onclick = () => { isMini = false; renderPanel(); };
        } else {
            panel.innerHTML = `
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; border-bottom:1px solid rgba(168,85,247,0.3); padding-bottom:8px;">
                    <div style="display:flex; align-items:center; gap:8px;">
                        <span style="font-size:18px; filter: drop-shadow(0 0 8px #c084fc);">👑</span>
                        <div>
                            <h3 style="margin:0; color:#fae8ff; font-size:14px; font-weight:800; letter-spacing:0.8px; text-shadow: 0 0 10px rgba(192,132,252,0.5);">후이 ELITE PRO</h3>
                            <span style="font-size:9px; color:#c084fc; font-weight:600;">[SYSTEM V14.0 SECURE]</span>
                        </div>
                    </div>
                    <button id="btnMinimize" style="background:rgba(147, 51, 234, 0.25); border:1px solid rgba(192, 132, 252, 0.5); color:#fae8ff; cursor:pointer; padding:2px 8px; border-radius:6px; font-weight:bold;">−</button>
                </div>

                <div style="display:grid; grid-template-columns: 1fr 1fr; gap:8px; margin-bottom:10px;">
                    <div>
                        <label style="color:#d8b4fe; font-size:10px; font-weight:700; display:block; margin-bottom:3px;">Số vòng (Lần):</label>
                        <input id="inpMaxLoop" type="number" value="1" style="width:100%; padding:6px; background:rgba(10, 10, 25, 0.9); color:#fff; border:1px solid rgba(168, 85, 247, 0.6); border-radius:7px; box-sizing:border-box; font-size:11px; outline:none; text-align:center; font-weight:bold;">
                    </div>
                    <div>
                        <label style="color:#d8b4fe; font-size:10px; font-weight:700; display:block; margin-bottom:3px;">Nghỉ vòng (Phút):</label>
                        <input id="inpDelayMin" type="number" value="0" style="width:100%; padding:6px; background:rgba(10, 10, 25, 0.9); color:#fff; border:1px solid rgba(168, 85, 247, 0.6); border-radius:7px; box-sizing:border-box; font-size:11px; outline:none; text-align:center; font-weight:bold;">
                    </div>
                </div>

                <div style="margin-bottom:10px;">
                    <label style="color:#d8b4fe; font-size:10px; font-weight:700; display:block; margin-bottom:3px;">Delay bước (Giây):</label>
                    <input id="inpStepDelay" type="number" value="2.5" step="0.5" min="1" style="width:100%; padding:6px; background:rgba(10, 10, 25, 0.9); color:#fff; border:1px solid rgba(168, 85, 247, 0.6); border-radius:7px; box-sizing:border-box; font-size:11px; outline:none; text-align:center; font-weight:bold;">
                </div>

                <div style="margin-bottom:10px; display:flex; align-items:center; justify-content:space-between; background:rgba(147, 51, 234, 0.15); padding:6px 10px; border-radius:7px; border:1px solid rgba(192, 132, 252, 0.3);">
                    <div style="display:flex; align-items:center; gap:6px;">
                        <input type="checkbox" id="chkAntiSleep" checked style="accent-color: #c084fc; cursor:pointer; width:14px; height:14px;"> 
                        <label for="chkAntiSleep" style="cursor:pointer; color:#e9d5ff; font-weight:700; font-size:11px;">Chống ngủ Tab</label>
                    </div>
                    <div style="color:#d8b4fe; font-weight:bold; font-size:11px;">
                        Đã xong: <span id="successCounter" style="color:#4ade80; font-size:13px; text-shadow: 0 0 6px rgba(74,222,128,0.5);">${successCount}</span>
                    </div>
                </div>

                <div style="margin-bottom:8px; color:#f3e8ff; font-size:11px;">Trạng thái: <span id="stt" style="color:#e879f9; font-weight:bold;">Sẵn sàng chạy</span></div>
                
                <div style="background:rgba(10, 10, 25, 0.9); height:9px; border-radius:5px; overflow:hidden; margin-bottom:12px; border: 1px solid rgba(168, 85, 247, 0.4);">
                    <div id="progressBar" style="width:0%; height:100%; background:linear-gradient(90deg, #9333ea, #c084fc, #f472b6); transition: width 0.3s ease; box-shadow: 0 0 10px #c084fc;"></div>
                </div>

                <div style="display:flex; gap:6px;">
                    <button id="btnStart" style="flex:1; padding:9px; background:linear-gradient(135deg, #7c3aed, #c084fc); color:white; border:none; border-radius:8px; font-weight:bold; cursor:pointer; box-shadow:0 4px 15px rgba(147, 51, 234, 0.6); transition:0.2s; letter-spacing:0.5px;">CHẠY NGAY</button>
                    <button id="btnPause" style="flex:1; padding:9px; background:linear-gradient(135deg, #d97706, #b45309); color:white; border:none; border-radius:8px; font-weight:bold; cursor:pointer; display:none;">TẠM DỪNG</button>
                    <button id="btnStop" style="flex:1; padding:9px; background:linear-gradient(135deg, #dc2626, #991b1b); color:white; border:none; border-radius:8px; font-weight:bold; cursor:pointer; display:none;">DỪNG</button>
                </div>
                <div id="btnResume" style="display:none; text-align:center; margin-top:6px;">
                     <button style="width:100%; padding:7px; background:linear-gradient(135deg, #4338ca, #6366f1); color:white; border:none; border-radius:8px; font-weight:bold; cursor:pointer;">TIẾP TỤC</button>
                </div>
            `;
            const btnMinimize = panel.querySelector("#btnMinimize");
            btnMinimize.onclick = () => { isMini = true; renderPanel(); };
            bindMainEvents();
        }
    };
    
    document.body.appendChild(panel);
    renderPanel();

    function bindMainEvents() {
        if(isMini) return;
        const btnStart = panel.querySelector("#btnStart");
        const btnPause = panel.querySelector("#btnPause");
        const btnStop = panel.querySelector("#btnStop");
        const btnResumeDiv = panel.querySelector("#btnResume");
        const btnResume = btnResumeDiv.querySelector("button");

        if (btnStart) btnStart.onclick = startProcess;
        if (btnPause) btnPause.onclick = () => { isPaused = true; updateUIState(); };
        if (btnResume) btnResume.onclick = () => { isPaused = false; updateUIState(); };
        if (btnStop) btnStop.onclick = () => { 
            if(confirm("Bạn có chắc muốn DỪNG tiến trình?")) { 
                shouldStop = true; isPaused = false; toggleAntiSleep(false);
                updateStatus("Đã hủy quy trình", "#f87171");
            } 
        };
    }

    function updateUIState() {
        if(isMini) return;
        const btnStart = panel.querySelector("#btnStart");
        const btnPause = panel.querySelector("#btnPause");
        const btnStop = panel.querySelector("#btnStop");
        const btnResumeDiv = panel.querySelector("#btnResume");
        if (!btnStart) return;
        if (audioLoop && !audioLoop.paused) { 
            btnStart.style.display = "none";
            btnStop.style.display = "block";
            if (isPaused) {
                btnPause.style.display = "none";
                btnResumeDiv.style.display = "block";
            } else {
                btnPause.style.display = "block";
                btnResumeDiv.style.display = "none";
            }
        } else { 
            btnStart.style.display = "block";
            btnPause.style.display = "none";
            btnStop.style.display = "none";
            btnResumeDiv.style.display = "none";
        }
    }

    function updateStatus(text, color = "#f3e8ff") {
        if (isMini) {
            const el = panel.querySelector("#miniStt");
            if (el) { el.innerText = text; el.style.color = color; }
        } else {
            const el = panel.querySelector("#stt");
            if (el) { el.innerText = text; el.style.color = color; }
            const counterEl = panel.querySelector("#successCounter");
            if (counterEl) counterEl.innerText = successCount;
        }
    }
    
    function updateProgress(percent) {
        if (isMini) {
            const el = panel.querySelector("#miniBar");
            if (el) el.style.width = percent + "%";
            const countEl = panel.querySelector("#miniCount");
            if (countEl) countEl.innerText = `[${successCount}]`;
        } else {
            const el = panel.querySelector("#progressBar");
            if (el) el.style.width = percent + "%";
        }
    }

    async function startProcess() {
        let maxLoops = 1, delayMinutes = 0, stepDelaySec = 2.5, useAntiSleep = true;
        if (!isMini) {
            maxLoops = parseInt(panel.querySelector("#inpMaxLoop").value) || 1;
            delayMinutes = parseInt(panel.querySelector("#inpDelayMin").value) || 0;
            stepDelaySec = parseFloat(panel.querySelector("#inpStepDelay").value) || 2.5;
            useAntiSleep = panel.querySelector("#chkAntiSleep").checked;
        }
        let stepDelayMs = stepDelaySec * 1000;

        let currentLoop = 0;
        shouldStop = false;
        isPaused = false;

        if (useAntiSleep) toggleAntiSleep(true);
        updateUIState();

        while (currentLoop < maxLoops && !shouldStop) {
            currentLoop++;

            for (let i = 0; i < steps.length; i++) {
                if (shouldStop) break;
                while (isPaused) { await sleep(500); if (shouldStop) break; }

                let step = steps[i];
                updateStatus(`[V.${currentLoop}] ${step.name}`, "#e879f9");
                updateProgress((step.step / 54) * 100);

                if (step.specialAction === "CLICK_META_RESULT") {
                    let dummyStt = { innerText: "" }; 
                    let success = await clickMetaResult(dummyStt);
                    updateStatus(dummyStt.innerText || "Chọn Meta...", "#f3e8ff");
                    if (!success) {
                        let inputEl = getElementByXpath(INPUT_XPATH);
                        if(inputEl) inputEl.dispatchEvent(new KeyboardEvent('keydown', {key: 'Enter', keyCode: 13, bubbles: true}));
                    }
                    await waitForGlobalLoading(updateStatus);
                    await sleep(stepDelayMs);
                    continue;
                }

                let el = null;
                // Cơ chế quét thông minh đa tầng chống lỗi
                for(let retry = 0; retry < 6; retry++){
                    if (shouldStop) break;
                    if (step.xpath) el = getElementByXpath(step.xpath);
                    if (!el) {
                        if (step.name === "Next") el = findButtonSmart(["Next", "Tiếp", "Tiếp tục", "次へ"]);
                        else if (step.name === "Submit") el = findButtonSmart(["Submit", "Gửi", "Send", "送信"]);
                        else if (step.name === "Done") el = findButtonSmart(["Done", "Xong", "Hoàn tất", "Đóng", "Close", "完了"]);
                        else el = findButtonSmart([step.name]);
                    }
                    if(el) break;
                    await sleep(800);
                }

                if (shouldStop) break;

                if (el) {
                    if (step.inputData) {
                        el.style.border = "2px solid #e879f9";
                        simulateInput(el, step.inputData);
                        updateStatus("Đang nhập liệu...", "#f3e8ff");
                        await sleep(3000);
                    } else {
                        el.style.border = "2px solid #c084fc";
                        safeClick(el);
                        
                        if (step.name === "Next" || step.name === "Submit") {
                            updateStatus("Chờ phản hồi...", "#d8b4fe");
                            await waitForElementToDisappear(el);
                        }
                        
                        await waitForGlobalLoading(updateStatus);
                        updateStatus(`Đợi ${stepDelaySec}s...`, "#a78bfa");
                        await sleep(stepDelayMs);
                    }
                } else {
                    // Xử lý thông minh khi mất nút: Bỏ qua bước này hoặc tự động thử lại thay vì báo lỗi đứng hình
                    console.warn(`[Cảnh báo nhẹ] Bỏ qua bước ${step.step}: ${step.name}`);
                    updateStatus(`Bỏ qua bước: ${step.name}`, "#facc15");
                    await sleep(1000);
                }
            }

            if (shouldStop) break;

            successCount++;
            updateStatus("Đã xong 1 lượt!", "#4ade80");

            if (currentLoop < maxLoops) {
                if (delayMinutes > 0) {
                    let secondsLeft = delayMinutes * 60;
                    while (secondsLeft > 0 && !shouldStop) {
                        updateStatus(`Nghỉ vòng: ${Math.floor(secondsLeft/60)}p ${secondsLeft%60}s`, "#38bdf8");
                        await sleep(1000);
                        secondsLeft--;
                    }
                } else await sleep(2000);
            }
        }

        if (!shouldStop) {
            updateStatus("HOÀN TẤT TẤT CẢ!", "#4ade80");
            updateProgress(100);
            alert(`👑 후이 Pro: Hoàn thành xuất sắc ${successCount} lần!`);
        }
        
        toggleAntiSleep(false);
        updateUIState();
    };

})();